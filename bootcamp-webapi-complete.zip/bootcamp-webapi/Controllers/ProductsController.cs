using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Collections.Generic;
using Pivotal.Extensions.Configuration.ConfigServer;
using Microsoft.Extensions.Configuration;

namespace bootcamp_demo2_practice.Controllers
{
   [Route("api/[controller]")]
   public class ProductsController: Controller
   {
       public ProductsController(IConfigurationRoot config) {
           Config = config;
       }
       private IConfigurationRoot Config {get; set;}

       // GET api/products
       [HttpGet]
       public IEnumerable<string> Get()
       {
           System.Console.WriteLine("connection string is " + Config["productdbconnstring"]);
           System.Console.WriteLine("Log level from config is " + Config["loglevel"]);
           return new string[] { "product1", "product2" };
       }
   }
}
